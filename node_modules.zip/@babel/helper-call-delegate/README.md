# @babel/helper-call-delegate

> Helper function to call delegate

See our website [@babel/helper-call-delegate](https://babeljs.io/docs/en/next/babel-helper-call-delegate.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-call-delegate
```

or using yarn:

```sh
yarn add @babel/helper-call-delegate --dev
```
