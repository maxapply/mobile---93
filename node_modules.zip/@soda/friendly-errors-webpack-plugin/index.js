
const FriendlyErrorsWebpackPlugin = require('./src/friendly-errors-plugin');

module.exports = FriendlyErrorsWebpackPlugin;